Do not remove or move any items from Snakie folder.
If you do you will get an error such as "snakie.png was not found"
To fix this download item related to item from github page: https://github.com/SpiralGaming/Snakie